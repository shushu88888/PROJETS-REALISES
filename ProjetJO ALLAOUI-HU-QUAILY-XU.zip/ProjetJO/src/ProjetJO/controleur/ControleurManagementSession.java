/**
 * @author Haiyue Xu
 */
package ProjetJO.controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
import ProjetJO.modele.Enregistrement;
import ProjetJO.modele.Session;
import ProjetJO.vues.PanelGererSessions;

public class ControleurManagementSession implements ActionListener {
    private PanelGererSessions vue;
    private Enregistrement modele;

    // Constructeur
    public ControleurManagementSession(Enregistrement modele, PanelGererSessions vue) {
        this.modele = modele;
        this.vue = vue;
    }

    public void actionPerformed(ActionEvent e) {
        // Ajouter une session
        if (e.getActionCommand().equals("Ajouter Session")) {
            ajouterSession();
        }
        // Supprimer une session
        else if (e.getActionCommand().equals("Supprimer Session")) {
            supprimerSession();
        }
    }

    private void ajouterSession() {
        try {
            // Validation des champs
            if (vue.getNumsession().isEmpty() || vue.getSessionName().isEmpty() || vue.getStartDate().isEmpty()
                    || vue.getEndDate().isEmpty() || vue.getparticipants().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numSessionStr = vue.getNumsession().trim();
            String sessionName = vue.getSessionName().trim();
            String startDateStr = vue.getStartDate().trim();
            String endDateStr = vue.getEndDate().trim();
            String participantsStr = vue.getparticipants().trim(); // Participants en tant que chaîne

            int numSession = Integer.parseInt(numSessionStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date startDate = dateFormat.parse(startDateStr);
            Date endDate = dateFormat.parse(endDateStr);

            // Créer une nouvelle session avec les participants
            Session addSession = new Session(numSession, sessionName, startDate, endDate, participantsStr);

            if (modele.contientSession(addSession)) {
                JOptionPane.showMessageDialog(null, "La session existe déjà.");
            } else {
                modele.ajouterSession(addSession);
                JOptionPane.showMessageDialog(null, "Session ajoutée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Sessions : " + modele.getSessions());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro de session doit être un nombre.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de l'ajout de la session: " + ex.getMessage());
        }
    }

    private void supprimerSession() {
        try {
            // Validation des champs
            if (vue.getNumsession().isEmpty() || vue.getSessionName().isEmpty() || vue.getStartDate().isEmpty()
                    || vue.getEndDate().isEmpty() || vue.getparticipants().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numSessionStr = vue.getNumsession().trim();
            String sessionName = vue.getSessionName().trim();
            String startDateStr = vue.getStartDate().trim();
            String endDateStr = vue.getEndDate().trim();
            String participantsStr = vue.getparticipants().trim(); // Participants en tant que chaîne

            int numSession = Integer.parseInt(numSessionStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date startDate = dateFormat.parse(startDateStr);
            Date endDate = dateFormat.parse(endDateStr);

            // Créer une nouvelle session avec les participants
            Session removeSession = new Session(numSession, sessionName, startDate, endDate, participantsStr);

            // Vérifier si la session existe avant de la supprimer
            if (modele.contientSession(removeSession)) {
                modele.supprimerSession(removeSession);
                JOptionPane.showMessageDialog(null, "Session supprimée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Sessions : " + modele.getSessions());
            } else {
                JOptionPane.showMessageDialog(null, "La session n'existe pas.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro de session doit être un nombre.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de la suppression de la session: " + ex.getMessage());
        }
    }
}
