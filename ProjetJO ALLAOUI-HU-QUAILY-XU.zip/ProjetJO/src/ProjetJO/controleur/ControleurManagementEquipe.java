/**
 * @author Haiyue Xu
 */
package ProjetJO.controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
import ProjetJO.modele.Enregistrement;
import ProjetJO.modele.Equipe;
import ProjetJO.vues.PanelGererEquipe;

public class ControleurManagementEquipe implements ActionListener {
    private PanelGererEquipe vue;
    private Enregistrement modele;

    // Constructeur
    public ControleurManagementEquipe(Enregistrement modele, PanelGererEquipe vue) {
        this.modele = modele;
        this.vue = vue;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Ajouter équipe")) { // ajouter les équipes
            ajouterEquipe();
        } else if (e.getActionCommand().equals("Supprimer équipe")) { // supprimer les équipes
            supprimerEquipe();
        }
    }

    private void ajouterEquipe() {
        try {
            // Validation des champs
            if (vue.getNum().isEmpty() || vue.getNom().isEmpty() || vue.getDescription().isEmpty()
                    || vue.getCreationDate().isEmpty() || vue.getNbMembres().isEmpty() || vue.getPays().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numStr = vue.getNum().trim();
            String nbMembresStr = vue.getNbMembres().trim();
            String nom = vue.getNom().trim();
            String description = vue.getDescription().trim();
            String creationDateStr = vue.getCreationDate().trim();
            String pays = vue.getPays().trim();

            int num = Integer.parseInt(numStr);
            int nbMembres = Integer.parseInt(nbMembresStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date dateDebut = dateFormat.parse(creationDateStr);

            Equipe addEquipe = new Equipe(num, nom, description, dateDebut, nbMembres, pays);
            
            if (modele.contientEquipe(addEquipe)) {
                JOptionPane.showMessageDialog(null, "L'équipe existe déjà.");
            } else {
                modele.ajouterEquipe(addEquipe);
                JOptionPane.showMessageDialog(null, "Équipe ajoutée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Équipe : " + modele.getEquipes());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro d'équipe et le nombre de membres doivent être des nombres.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de l'ajout de l'équipe: " + ex.getMessage());
        }
    }

    private void supprimerEquipe() {
        try {
            // Validation des champs
            if (vue.getNum().isEmpty() || vue.getNom().isEmpty() || vue.getDescription().isEmpty()
                    || vue.getCreationDate().isEmpty() || vue.getNbMembres().isEmpty() || vue.getPays().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numStr = vue.getNum().trim();
            String nbMembresStr = vue.getNbMembres().trim();
            String nom = vue.getNom().trim();
            String description = vue.getDescription().trim();
            String creationDateStr = vue.getCreationDate().trim();
            String pays = vue.getPays().trim();

            int num = Integer.parseInt(numStr);
            int nbMembres = Integer.parseInt(nbMembresStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date dateDebut = dateFormat.parse(creationDateStr);

            Equipe removeEquipe = new Equipe(num, nom, description, dateDebut, nbMembres, pays);
            
            if (modele.contientEquipe(removeEquipe)) {
                modele.supprimerEquipe(removeEquipe);
                JOptionPane.showMessageDialog(null, "Équipe supprimée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Équipe : " + modele.getEquipes());
            } else {
                JOptionPane.showMessageDialog(null, "L'équipe n'existe pas.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro d'équipe et le nombre de membres doivent être des nombres.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de la suppression de l'équipe: " + ex.getMessage());
        }
    }
}
