/**
 * @author Haiyue Xu
 */
package ProjetJO.controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import ProjetJO.modele.*;
import ProjetJO.vues.*;

public class ControleurManagementEpreuve implements ActionListener {
    private PanelGererEpreuve vue; 
    private Enregistrement modele;

    // Constructeur 
    public ControleurManagementEpreuve(Enregistrement modele, PanelGererEpreuve vue) {
        this.modele = modele;
        this.vue = vue;
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals("Ajouter épreuve")) {  
            ajouterEpreuve();
        } else if (command.equals("Supprimer épreuve")) { 
            supprimerEpreuve();
        }
    }

    private void ajouterEpreuve() {
        try {
            // Validation des champs
            if (vue.getNumEpreuve().isEmpty() || vue.getNomEpreuve().isEmpty() || vue.getDateDebut().isEmpty()
                    || vue.getDateFin().isEmpty() || vue.getLieu().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numEpreuveStr = vue.getNumEpreuve().trim();
            String nomEpreuve = vue.getNomEpreuve().trim();
            String dateDebutStr = vue.getDateDebut().trim();
            String dateFinStr = vue.getDateFin().trim();
            String lieu = vue.getLieu().trim();

            int numEpreuve = Integer.parseInt(numEpreuveStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date dateDebut = dateFormat.parse(dateDebutStr);
            Date dateFin = dateFormat.parse(dateFinStr);

            Epreuve addEpreuve = new EPRindividuelle(numEpreuve, nomEpreuve, dateDebut, dateFin, lieu);

            if (modele.contientEpreuve(addEpreuve)) {
                JOptionPane.showMessageDialog(null, "L'épreuve existe déjà.");
            } else {
                modele.ajouterEpreuve(addEpreuve);
                JOptionPane.showMessageDialog(null, "Épreuve ajoutée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Épreuves : " + modele.getEpreuves());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro d'épreuve doit être un nombre.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de l'ajout de l'épreuve: " + ex.getMessage());
        }
    }

    private void supprimerEpreuve() {
        try {
            // Validation des champs
            if (vue.getNumEpreuve().isEmpty() || vue.getNomEpreuve().isEmpty() || vue.getDateDebut().isEmpty()
                    || vue.getDateFin().isEmpty() || vue.getLieu().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tous les champs doivent être remplis.");
                return;
            }

            // Nettoyage des valeurs
            String numEpreuveStr = vue.getNumEpreuve().trim();
            String nomEpreuve = vue.getNomEpreuve().trim();
            String dateDebutStr = vue.getDateDebut().trim();
            String dateFinStr = vue.getDateFin().trim();
            String lieu = vue.getLieu().trim();

            int numEpreuve = Integer.parseInt(numEpreuveStr);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date dateDebut = dateFormat.parse(dateDebutStr);
            Date dateFin = dateFormat.parse(dateFinStr);

            Epreuve removeEpreuve = new EPRindividuelle(numEpreuve, nomEpreuve, dateDebut, dateFin, lieu);

            if (modele.contientEpreuve(removeEpreuve)) {
                modele.supprimerEpreuve(removeEpreuve);
                JOptionPane.showMessageDialog(null, "Épreuve supprimée avec succès.");
                JOptionPane.showMessageDialog(null, "La liste des Épreuves : " + modele.getEpreuves());
            } else {
                JOptionPane.showMessageDialog(null, "L'épreuve n'existe pas.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Le numéro d'épreuve doit être un nombre.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erreur de format de date: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur lors de la suppression de l'épreuve: " + ex.getMessage());
        }
    }
}
