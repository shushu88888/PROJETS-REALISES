/**
 * @author Aymane Allaoui
 */
package ProjetJO.modele;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class AppliMain {

    public static Planning creerPlanning() throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        // Création de joueurs
        Joueur joueur1 = new Joueur(1, "Dupont", "Pierre", "France", null);
        Joueur joueur2 = new Joueur(2, "Martin", "Jean", "France", null);
        Joueur joueur3 = new Joueur(3, "Dubois", "Marie", "Canada", null);
        Joueur joueur4 = new Joueur(4, "Tremblay", "Luc", "Canada", null);
        Joueur joueur5 = new Joueur(5, "Smith", "Anna", "USA", null);
        Joueur joueur6 = new Joueur(6, "Doe", "John", "USA", null);
        Joueur joueur7 = new Joueur(7, "Wei", "Liu", "China", null);
        Joueur joueur8 = new Joueur(8, "Jing", "Chen", "China", null);
        Joueur joueur9 = new Joueur(9, "Patel", "Kumar", "India", null);
        Joueur joueur10 = new Joueur(10, "Singh", "Rajesh", "India", null);
        Joueur joueur11 = new Joueur(11, "Nguyen", "Mai", "Vietnam", null);
        Joueur joueur12 = new Joueur(12, "Garcia", "Carlos", "Spain", null);
        Joueur joueur13 = new Joueur(13, "Kim", "Jisoo", "South Korea", null);
        Joueur joueur14 = new Joueur(14, "Ivanov", "Sergei", "Russia", null);
        Joueur joueur15 = new Joueur(15, "Tanaka", "Yuki", "Japan", null);
        Joueur joueur16 = new Joueur(16, "Rodriguez", "Luisa", "Brazil", null);

        // Création des équipes
        Equipe equipe1 = new Equipe(1, "Equipe A", "Description A", dateFormat.parse("01/01/2020"), 2, "France");
        Equipe equipe2 = new Equipe(2, "Equipe B", "Description B", dateFormat.parse("01/01/2020"), 2, "Canada");
        Equipe equipe3 = new Equipe(3, "Equipe C", "Description C", dateFormat.parse("01/01/2020"), 2, "USA");
        Equipe equipe4 = new Equipe(4, "Equipe D", "Description D", dateFormat.parse("01/01/2020"), 2, "China");
        Equipe equipe5 = new Equipe(5, "Equipe E", "Description E", dateFormat.parse("01/01/2020"), 2, "India");
        Equipe equipe6 = new Equipe(6, "Equipe F", "Description F", dateFormat.parse("01/01/2020"), 2, "Vietnam");

        // Ajout des joueurs aux équipes
        equipe1.ajouterJoueur(joueur1);
        equipe1.ajouterJoueur(joueur2);

        equipe2.ajouterJoueur(joueur3);
        equipe2.ajouterJoueur(joueur4);

        equipe3.ajouterJoueur(joueur5);
        equipe3.ajouterJoueur(joueur6);

        equipe4.ajouterJoueur(joueur7);
        equipe4.ajouterJoueur(joueur8);

        equipe5.ajouterJoueur(joueur9);
        equipe5.ajouterJoueur(joueur10);

        equipe6.ajouterJoueur(joueur11);
        equipe6.ajouterJoueur(joueur12);

        // Création des épreuves collectives
        EPRcollective epreuveCollective1 = new EPRcollective(1, "Football", dateFormat.parse("10/07/2024 10:00"), dateFormat.parse("10/07/2024 12:00"), "Stade A", "collective");
        epreuveCollective1.ajouterParticipant(equipe1);
        epreuveCollective1.ajouterParticipant(equipe2);

        EPRcollective epreuveCollective2 = new EPRcollective(2, "Basketball", dateFormat.parse("10/07/2024 14:00"), dateFormat.parse("10/07/2024 16:00"), "Stade B", "collective");
        epreuveCollective2.ajouterParticipant(equipe3);
        epreuveCollective2.ajouterParticipant(equipe4);

        // Création des épreuves individuelles
        EPRindividuelle epreuveIndividuelle1 = new EPRindividuelle(3, "Tennis", dateFormat.parse("13/07/2024 10:00"), dateFormat.parse("13/07/2024 12:00"), "Court A");
        epreuveIndividuelle1.ajouterParticipant(joueur13);
        epreuveIndividuelle1.ajouterParticipant(joueur14);

        EPRindividuelle epreuveIndividuelle2 = new EPRindividuelle(4, "Badminton", dateFormat.parse("14/07/2024 10:00"), dateFormat.parse("14/07/2024 12:00"), "Court B");
        epreuveIndividuelle2.ajouterParticipant(joueur15);
        epreuveIndividuelle2.ajouterParticipant(joueur16);

        // Création des sessions
        Session sessionCollective1 = new Session(1, epreuveCollective1.getNomEpreuve(), epreuveCollective1.getDateDeb(), epreuveCollective1.getDateFin(), epreuveCollective1.getParticipants());
        Session sessionCollective2 = new Session(2, epreuveCollective2.getNomEpreuve(), epreuveCollective2.getDateDeb(), epreuveCollective2.getDateFin(), epreuveCollective2.getParticipants());
        Session sessionIndividuelle1 = new Session(3, epreuveIndividuelle1.getNomEpreuve(), epreuveIndividuelle1.getDateDeb(), epreuveIndividuelle1.getDateFin(), epreuveIndividuelle1.getParticipants());
        Session sessionIndividuelle2 = new Session(4, epreuveIndividuelle2.getNomEpreuve(), epreuveIndividuelle2.getDateDeb(), epreuveIndividuelle2.getDateFin(), epreuveIndividuelle2.getParticipants());

        // Création du planning
        Planning planning = new Planning();
        planning.ajouterSession(sessionCollective1);
        planning.ajouterSession(sessionCollective2);
        planning.ajouterSession(sessionIndividuelle1);
        planning.ajouterSession(sessionIndividuelle2);

        return planning;
    }


}
