/**
 * @author Aymane Allaoui
 */ 

package ProjetJO.modele;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Collection;
import java.util.Date;

public class Equipe {

    private int numE;
    private String NomE;
    private String DescE;
    private Date DateCreaE;
    private String PaysE;
    private Float ScoreE;
    private int nbmembres;
    private ArrayList<Joueur> joueurs;

    public Equipe(int numE, String NomE, String DescE, Date DateCreaE, int nbmembres, String PaysE) {
        this.numE = numE;
        this.NomE = NomE;
        this.DescE = DescE;
        this.DateCreaE = DateCreaE;
        this.nbmembres = nbmembres;
        this.PaysE = PaysE;
        this.joueurs = new ArrayList<>();
    }

    // Méthodes pour gérer les joueurs
    public void ajouterJoueur(Joueur j) {
        if (joueurs.size() < nbmembres) {
            joueurs.add(j);
            j.setSonEquipe(this);
        } else {
            throw new IllegalArgumentException("L'équipe est déjà complète.");
        }
    }

    public void supprimerJoueur(Joueur joueur) {
        joueurs.remove(joueur);
        joueur.setSonEquipe(null);
    }

    // Getters et setters
    public String getNom() {
        return NomE;
    }

    public void setNom(String nom) {
        this.NomE = nom;
    }

    public int getNombreDeMembres() {
        return nbmembres;
    }

    public void setNombreDeMembres(int nombreDeMembres) {
        this.nbmembres = nombreDeMembres;
    }

    public ArrayList<Joueur> getJoueurs() {
        return joueurs;
    }

    public int getNumE() {
        return numE;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Equipe equipe = (Equipe) o;
        return numE == equipe.numE &&
        		nbmembres == equipe.nbmembres &&
                Objects.equals(NomE, equipe.NomE) &&
                Objects.equals(DescE, equipe.DescE) &&
                Objects.equals(DateCreaE, equipe.DateCreaE) &&
                Objects.equals(PaysE, equipe.PaysE);
    }


    public String toString() {
        return NomE + '\'' +
                " : " + joueurs;
    }
}
