/**
 * @author HU Shuya
 */

package ProjetJO.modele;

import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

// classe abstraite fournie par Swing pour faciliter la création de modèles de tableaux personnalisés
public class ModeleTableauEpreuves extends AbstractTableModel implements Serializable{
    // ----------------------------------
    // attribut
    // --------------------------------------
    private final String[] columnNames = { "Numero", "Nom Epreuve", "Date Debut", "Date Fin", "Participant" };
    private List<Object[]> rowData;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    // ----------------------------------
    // Constructeur
    // --------------------------------------
    public ModeleTableauEpreuves(List<Session> sessions) {
        rowData = new ArrayList<>();
        for (Session session : sessions) {
            for (Object participant : session.getParticipants()) {
                rowData.add(new Object[] {
                        session.getNumero(),
                        session.getNomEpreuve(),
                        dateFormat.format(session.getDateDebut()),
                        dateFormat.format(session.getDateFin()),
                        participant.toString()
                });
            }
        }
    }

    public int getRowCount() {
        return rowData.size(); // Retourne le nombre de lignes dans le tableau.
    }

    public int getColumnCount() {
        return columnNames.length; // Retourne le nombre de colonnes dans le tableau.
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        return rowData.get(rowIndex)[columnIndex]; // Retourne la valeur à la position spécifiée dans le tableau.
    }

    public String getColumnName(int column) {
        return columnNames[column]; // Retourne le nom de la colonne à l'index spécifié
    }

    public void setSessions(List<Session> sessions) {
        // Met à jour les données du modèle avec une nouvelle liste de sessions.
        rowData.clear(); // vide la liste rowData
        for (Session session : sessions) {
            // parcouru chaque élément de la liste sessions

            for (Object participant : session.getParticipants()) {
                // parcouru chaque élément de la liste participantS. RENVOIE une iste d'objet
                // Objet

                rowData.add(new Object[] {
                        // crée un nouveau tableau d'objets contenant les informations de la session et
                        // du participant actuel, puis ajoute ce tableau à la liste
                        session.getNumero(),
                        session.getNomEpreuve(),
                        dateFormat.format(session.getDateDebut()),
                        dateFormat.format(session.getDateFin()),
                        participant.toString()
                });
            }
        }
        fireTableDataChanged(); // met à jour les données du modèle de tableau avec une nouvelle liste de
                                // sessions
    }
}
