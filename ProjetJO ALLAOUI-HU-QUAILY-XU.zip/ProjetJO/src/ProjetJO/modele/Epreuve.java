/**
 * @author Aymane Allaoui
 */
package ProjetJO.modele;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.io.Serializable;


public abstract class Epreuve implements Serializable {

    private int numEpreu;
    private String nomEpreu;
    private String DescEpreu;
    private String StatusEpreu;
    private ArrayList<Equipe> equipes;
    String typeEpreuve;
    protected Date dateDebut;
    protected Date dateFin;
    protected String lieu;
    protected int points;

    public Epreuve(int numEpreu, String nom, Date dateDebut, Date dateFin, String lieu) {
        this.numEpreu = numEpreu;
        this.nomEpreu = nom;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.lieu = lieu;
        this.equipes = new ArrayList<>();
    }

    public void AjoutEquipe(Equipe e) {
        equipes.add(e);
    }

    public void SupprimerE(Equipe e) {
        equipes.remove(e);
    }

    // Méthode pour vérifier si une épreuve existe

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Epreuve epreuve = (Epreuve) o;
        return numEpreu == epreuve.numEpreu &&
               Objects.equals(nomEpreu, epreuve.nomEpreu) &&
               Objects.equals(dateDebut, epreuve.dateDebut) &&
               Objects.equals(dateFin, epreuve.dateFin) &&
               Objects.equals(lieu, epreuve.lieu);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numEpreu, nomEpreu, dateDebut, dateFin, lieu);
    }

    // Méthodes abstraites
    public abstract void ajouterParticipant(Object participant);
    public abstract void supprimerParticipant(Object participant);
    public abstract ArrayList<Object> getParticipants();
    public abstract void attribuerPoints(List<Object> classement);

    // Getters et setters
    public String getNomEpreuve() {
        return nomEpreu;
    }

    public void setNomEpreuve(String nom) {
        this.nomEpreu = nom;
    }

    public Date getDateDeb() {
        return dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateDeb(Date date) {
        this.dateDebut = date;
    }

    public void setDateFin(Date date) {
        this.dateFin = date;
    }

    @Override
    public String toString() {
        return nomEpreu + " de type : " + typeEpreuve;
    }

    public void ajouterPoints(int points) {
        this.points += points;
    }
}
