/**
 * @author Aymane Allaoui
 */ 
package ProjetJO.modele;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EPRcollective extends Epreuve {

    private String Medaille;
    private String Desc;
    private ArrayList<Equipe> equipes;
    private String typeEpreuve;

    public EPRcollective(int numEpreu, String nom, Date dateDebut, Date dateFin, String lieu, String typeEpreuve) {
        super(numEpreu, nom, dateDebut, dateFin, lieu);
        this.equipes = new ArrayList<>();
        this.typeEpreuve = typeEpreuve;
    }

    // Implémentation des méthodes abstraites
    
    public void ajouterParticipant(Object participant) {
        if (participant instanceof Equipe) {
            equipes.add((Equipe) participant);
        } else {
            throw new IllegalArgumentException("Participant doit être une instance de Equipe");
        }
    }

    
    public void supprimerParticipant(Object participant) {
        if (participant instanceof Equipe) {
            equipes.remove(participant);
        } else {
            throw new IllegalArgumentException("Participant doit être une instance de Equipe");
        }
    }

    
    public ArrayList<Object> getParticipants() {
        return new ArrayList<>(equipes);
    }


    
    public String toString() {
        return "EPRcollective{" +
                "nom='" + getNomEpreuve() + '\'' +
                ", date=" + getDateDeb() +
                ", equipes=" + equipes +
                '}';
    }

	
	public void attribuerPoints(List<Object> classement) {
		// TODO Auto-generated method stub
		
	}
}
