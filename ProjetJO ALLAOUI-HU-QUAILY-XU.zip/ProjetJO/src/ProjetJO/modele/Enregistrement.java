// @author Amine Quaily

package ProjetJO.modele;

import java.util.ArrayList;
import java.util.List;

public class Enregistrement {
    private List<Equipe> equipes;
    private List<Session> sessions;
    private List<Joueur> joueurs;
    private List<Epreuve> epreuves;

    public Enregistrement() {
        this.equipes = new ArrayList<>();
        this.sessions = new ArrayList<>();
        this.joueurs = new ArrayList<>();
        this.epreuves = new ArrayList<>();
    }

    // Méthodes pour ajouter des éléments
    public void ajouterEquipe(Equipe equipe) {
        this.equipes.add(equipe);
    }

    public void ajouterSession(Session session) {
        this.sessions.add(session);
    }

    public void ajouterJoueur(Joueur joueur) {
        this.joueurs.add(joueur);
    }

    public void ajouterEpreuve(Epreuve epreuve) {
        this.epreuves.add(epreuve);
    }

    // Méthodes pour supprimer des éléments
    public void supprimerEquipe(Equipe equipe) {
        this.equipes.remove(equipe);
    }

    public void supprimerSession(Session session) {
        this.sessions.remove(session);
    }

    public void supprimerJoueur(Joueur joueur) {
        this.joueurs.remove(joueur);
    }

    public void supprimerEpreuve(Epreuve epreuve) {
        this.epreuves.remove(epreuve);
    }

    // Méthodes pour obtenir les listes
    public List<Equipe> getEquipes() {
        return equipes;
    }

    public List<Session> getSessions() {
        return sessions;
    }

    public List<Joueur> getJoueurs() {
        return joueurs;
    }

    public List<Epreuve> getEpreuves() {
        return epreuves;
    }
    
    // Méthode pour vérifier si une équipe existe
    public boolean contientEquipe(Equipe equipe) {
        for (Equipe e : this.equipes) {
            if (e.equals(equipe)) {
                return true;
            }
        }
        return false;
    }

 // Méthode pour vérifier si une épreuve existe
    public boolean contientEpreuve(Epreuve epreuve) {
        for (Epreuve e : this.epreuves) {
            if (e.equals(epreuve)) {
                return true;
            }
        }
        return false;
    }

 // Méthode pour vérifier si une session existe
    public boolean contientSession(Session session) {
        for (Session s : this.sessions) {
            if (s.equals(session)) {
                return true;
            }
        }
        return false;
    }

    
}
