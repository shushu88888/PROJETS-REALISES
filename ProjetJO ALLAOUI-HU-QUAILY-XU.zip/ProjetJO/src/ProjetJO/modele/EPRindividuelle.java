/**
 * @author Aymane Allaoui
 */
package ProjetJO.modele;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EPRindividuelle extends Epreuve {

    private String Medaille;
    private String Desc;
    private String typeEpreuve;
    private ArrayList<Joueur> joueurs;

    public EPRindividuelle(int numEpreu, String nom, Date dateDebut, Date dateFin, String lieu) {
        super(numEpreu, nom, dateDebut, dateFin, lieu);
        this.joueurs = new ArrayList<>();
    }

    
    public void ajouterParticipant(Object participant) {
        if (participant instanceof Joueur) {
            joueurs.add((Joueur) participant);
        } else {
            throw new IllegalArgumentException("Participant doit être une instance de Joueur");
        }
    }

    
    public void supprimerParticipant(Object participant) {
        if (participant instanceof Joueur) {
            joueurs.remove(participant);
        } else {
            throw new IllegalArgumentException("Participant doit être une instance de Joueur");
        }
    }

    
    public ArrayList<Object> getParticipants() {
        return new ArrayList<>(joueurs);
    }

    
    public void attribuerPoints(List<Object> classement) {
        int points = classement.size() + 5;
        for (Object participant : classement) {
            if (participant instanceof Joueur) {
                ((Joueur) participant).ajouterPoints(points);
                points--;
            }
        }
    }

    
    public String toString() {
        return "EPRindividuelle{" +
                "nom='" + getNomEpreuve() + '\'' +
                ", date=" + getDateDeb() +
                ", joueurs=" + joueurs +
                '}';
    }
}
