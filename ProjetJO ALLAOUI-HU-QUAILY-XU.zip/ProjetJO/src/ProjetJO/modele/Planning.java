/**
 * @author Amine Quaily
  @author HU Shuya
 */

package ProjetJO.modele;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class Planning implements Serializable {
    private List<Session> sessions;

    public Planning() {
        this.sessions = new ArrayList<>();
    }

    public void ajouterSession(Session session) {
        sessions.add(session);
        trierSessions();
    }

    public void supprimerSession(Session session) {
        sessions.remove(session);
    }

    private void trierSessions() {
        sessions.sort((s1, s2) -> s1.getDateDebut().compareTo(s2.getDateDebut()));
    }

    public List<Session> getToutesLesSessions() {
        return sessions;
    }

    public List<Session> getSessionsForDate(Date date) {
        List<Session> sessionsForDate = new ArrayList<>();
        for (Session session : sessions) {
            if (((Date) session.getDateDebut()).toLocalDate().equals(date.toLocalDate())) {
                sessionsForDate.add(session);
            }
        }
        return sessionsForDate;
    }

    @Override
    public String toString() {
        return "Planning{" +
                "sessions=" + sessions +
                '}';
    }
}

