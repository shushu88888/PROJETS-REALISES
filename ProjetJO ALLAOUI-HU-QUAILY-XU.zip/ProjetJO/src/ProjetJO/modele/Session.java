/**
 * @author Amine Quaily
 */
package ProjetJO.modele;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;
import java.util.Objects;

public class Session implements Serializable {
    private int numero;
    private String nomEpreuve;
    private Date dateDebut;
    private Date dateFin;
    private List<Object> participants; // Peut contenir des Joueurs ou des Equipes d'où l'attribut "Object"

    // Constructeur
    public Session(int numero, String nomEpreuve, Date dateDebut, Date dateFin, List<Object> participants) {
        this.numero = numero;
        this.nomEpreuve = nomEpreuve;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.participants = participants;
    }
    
    //Constructeur créée par Xu Haiyue pour la partie controleur
    public Session(int numero, String nomEpreuve, Date dateDebut, Date dateFin, String participantsStr) {
        this(numero, nomEpreuve, dateDebut, dateFin, new ArrayList<>());
        ajouterParticipant(participantsStr);
    }



	// Getters et Setters
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNomEpreuve() {
        return nomEpreuve;
    }

    public void setNomEpreuve(String nomEpreuve) {
        this.nomEpreuve = nomEpreuve;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public List<Object> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Object> participants) {
        this.participants = participants;
    }

    public String toString() {
        return nomEpreuve + '\'' +
                ", dateDebut=" + dateDebut +
                ", dateFin=" + dateFin +
                ", participants=" + participants +
                '}';
    }

    // Methode pour verifier si la session existe ou pas
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Session session = (Session) o;
        return numero == session.numero &&
               Objects.equals(nomEpreuve, session.nomEpreuve) &&
               Objects.equals(dateDebut, session.dateDebut) &&
               Objects.equals(dateFin, session.dateFin) &&
               Objects.equals(participants, session.participants);
    }
    
    
    
    // Méthode pour ajouter un participant (String) à la liste
    //C'est une methode pour enregistrer les données saisies, créée par Xu Haiyue
    public void ajouterParticipant(String participant) {
        if (participant != null && !participant.trim().isEmpty()) {
            participants.add(participant);
        } else {
            System.out.println("Le participant ne peut pas être nul ou vide.");
        }
    }
    
}

