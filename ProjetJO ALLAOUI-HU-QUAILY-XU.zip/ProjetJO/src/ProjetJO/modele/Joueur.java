/**
 * @author Aymane Allaoui
 */

package ProjetJO.modele;

import java.io.Serializable;

public class Joueur implements Serializable  {

  Equipe SonEquipe;
  //Classement SonClassement; //HU Shuya:crée des bug
  private int numJ;
  private String NomJ;
  private String PrenomJ;
  private String Pert;
  private String Gagner;
  private float score;
  private String Pays;
  private int points;

  public Joueur (int numJ ,String NomJ, String PrenomJ, String Pays , Equipe SonEquipe) {
    this.numJ = numJ;
    this.NomJ = NomJ;
    this.PrenomJ = PrenomJ;
    this.Pays = Pays;
    this.SonEquipe = SonEquipe;
    this.points = 0;
  }


  public void CheckJoueurPalm(int Joueur) {

  }

    // Méthode pour vérifier si un joueur existe
    public boolean equals(Joueur autreJoueur) {
        return this.numJ == autreJoueur.getNumJ();
    }
    ///Ajout de la methode getNumJ pour return le num du joueur 
    public int getNumJ() {
        return numJ;
    }

  // Getters et setters
    public String getNom() {
        return NomJ;
    }

    public void setNom(String NomJ) {
        this.NomJ = NomJ;
    }

    public String getPays() {
        return Pays;
    }

    public void setPays(String Pays) {
        this.Pays = Pays;
    }

    public Equipe getSonEquipe() {
        return SonEquipe;
    }

    public void setSonEquipe(Equipe SonEquipe) {
        this.SonEquipe = SonEquipe;
    }
    
    public void ajouterPoints(int points) {
        this.points += points;
    }
/*
    public String toString() {
        return "Joueur{" +
                "nom='" + NomJ + '\'' +
                ", pays='" + Pays + '\'' +
                ", sonEquipe=" + (SonEquipe != null ? SonEquipe.getNom() : "Aucune") +
                '}';
        //Ici , le programme va verifier si SonEquipe est vide ou pas 
        // Grace au caractere "?" si la condition est verifié , alors : SonEquipe.getNom() est executée
        // ":" correspond à "sinon" en java , si la condition n'est pas verifiée , alors "Aucune" est executée

*/
    public String toString() {
        return NomJ + PrenomJ;
       /// HU Shuya: fait simple
    }

}