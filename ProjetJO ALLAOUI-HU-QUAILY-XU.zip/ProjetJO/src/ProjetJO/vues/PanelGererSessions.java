/**
 * @author HU Shuya
 */

package ProjetJO.vues;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelGererSessions extends JPanel {

    // -----------------------------
    // Attributs
    // -----------------------------

    // champs de texte: ce que vous entrez
    private JTextField numsession;
    private JTextField sessionName;
    private JTextField startDate;
    private JTextField endDate;
    private JTextField participants;

    // Label
    private JLabel sessionnumLabel;
    private JLabel sessionNameLabel;
    private JLabel startDateLabel;
    private JLabel endDateLabel;
    private JLabel participantsLabel;

    // boutons
    private JButton addButton;
    private JButton deleteButton;

    // -----------------------------
    // Constructeur
    // -----------------------------
    public PanelGererSessions() {

        // -------------------------------
        // Initialiser les composants
        // --------------------------
        sessionnumLabel = new JLabel("Numéro de la session:");
        numsession = new JTextField(20);

        sessionNameLabel = new JLabel("Nom de la session:");
        sessionName = new JTextField(20);

        startDateLabel = new JLabel("Date de début (dd/MM/yyyy):");
        startDate = new JTextField(20);

        endDateLabel = new JLabel("Date de fin (dd/MM/yyyy):");
        endDate = new JTextField(20);

        participantsLabel = new JLabel("Lieu de la session:");
        participants = new JTextField(20);

        addButton = new JButton("Ajouter session");
        deleteButton = new JButton("Supprimer session");

        addButton.setBackground(new Color(230, 200, 100));
        deleteButton.setBackground(new Color(230, 200, 100));

        sessionName.setHorizontalAlignment(JLabel.CENTER);

        // ----------------------------------
        // Configurer la mise en page
        // -------------------------------------
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // border inter
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.1; // espace entre label et text
        add(sessionnumLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // vers haut
        add(numsession, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.1;
        add(sessionNameLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // vers haut
        add(sessionName, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.1;
        add(startDateLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // vers haut
        add(startDate, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.1;
        add(endDateLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // vers haut
        add(endDate, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.1;
        add(participantsLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // vers haut
        add(participants, gbc);

        // -------------------------------
        // Créer un panneau pour les boutons
        // -------------------------------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.setBackground(new Color(255, 255, 204));

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2; // pour que le bouton couvre deux colonnes
        add(buttonPanel, gbc);

        // foncd color
        setBackground(new Color(255, 255, 204));

        // border entre composant et bordure
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        /// Préparer la gestion des clics sur les boutons
        addButton.setActionCommand("Ajouter Session");
        deleteButton.setActionCommand("Supprimer Session");

        // ---------------------------
        // Test boutons dans la vue
        // ---------------------------
    /*
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Session est bien ajouter!");
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Session est bien supprimer!");
            }
        });
	*/
    }




    // --------------------------------------------
    //fenetre affichage
    //----------------------------------------------
/*
    public static void main(String[] args) {
        // Creer une fenetre
        JFrame frame = new JFrame("Gere sessions");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     // Créer un panneau principal avec BorderLayout
        JPanel panelGlobal = new JPanel(new BorderLayout());

        // Créer un panneau pour le titre
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("Gérer les sessions");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabel.setForeground(new Color(230, 230, 210)); // color fond
        titlePanel.add(titleLabel);

        // Créer une instance de PanelGererEquipe
        PanelGererSessions panel = new PanelGererSessions();
        // Ajouter les panneaux au panneau principal
        panelGlobal.add(titlePanel, BorderLayout.NORTH);
        panelGlobal.add(panel, BorderLayout.CENTER);

        // Ajouter le panneau principal à la fenêtre
        frame.add(panelGlobal);

        // Afficher la fenêtre
        frame.setVisible(true);

    }
*/




    // -----------------------------
    // Accesseurs
    // -----------------------------
    public String getNumsession() {
        return numsession.getText();
    }

    public String getSessionName() {
        return sessionName.getText();
    }

    public String getStartDate() {
        return startDate.getText();
    }

    public String getEndDate() {
        return endDate.getText();
    }

    public String getparticipants() {
        return participants.getText();
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

}
