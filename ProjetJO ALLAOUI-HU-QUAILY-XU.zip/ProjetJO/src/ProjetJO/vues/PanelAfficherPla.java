/**
 * @author HU Shuya
 */

package ProjetJO.vues;

import ProjetJO.modele.*;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PanelAfficherPla extends JPanel {

    // -------------------------
    // Attribut
    // -------------------------
    private Planning planning;

    // --------------------------
    // Constructeur
    // -------------------------
    public PanelAfficherPla(Planning planning) {

        this.planning = planning; // Initialisation du panneau avec le planning passé en paramètre

        // Configuration du layout du panneau en BoxLayout vertical
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(255, 255, 200)); // Changer la couleur de fond en jaune clair

        // Regrouper les sessions par date et les trier par ordre chronologique
        // FONCTIONNE avec ECLIPSE
        Map<LocalDate, List<Session>> sessionsByDate = planning.getToutesLesSessions().stream()
                .sorted((s1, s2) -> s1.getDateDebut().compareTo(s2.getDateDebut()))
                .collect(Collectors.groupingBy(session -> session.getDateDebut().toInstant()
                        .atZone(java.time.ZoneId.systemDefault()).toLocalDate()));

        // Create a table for each date ::Pour chaque date, créer une étiquette de date
        // et un tableau d'épreuves
        sessionsByDate.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    LocalDate date = entry.getKey();
                    List<Session> sessions = entry.getValue();

                    // Créer une étiquette de date avec la date actuelle
                    JLabel dateLabel = new JLabel(date.toString());
                    dateLabel.setFont(new Font("Arial", Font.BOLD, 14));
                    dateLabel.setBackground(new Color(255, 255, 200)); // Changer la couleur de fond en jaune clair
                    add(dateLabel);

                    // Créer un modèle de tableau d'épreuves basé sur les sessions de cette date
                    ModeleTableauEpreuves modeleTableauEpreuves = new ModeleTableauEpreuves(sessions);
                    JTable epreuvesTable = new JTable(modeleTableauEpreuves);

                    // Ajuster la largeur des colonnes du tableau
                    adjustColumnWidths(epreuvesTable);

                    // Ajouter le tableau dans un JScrollPane et l'ajouter au panneau
                    JScrollPane scrollPane = new JScrollPane(epreuvesTable);
                    add(scrollPane);
                });
    }



    
    // --------------------------
    //METHODE
    // --------------------------
    
    // Méthode pour ajuster la largeur des colonnes du tableau en fonction de la
    // longueur de leurs contenus
    private void adjustColumnWidths(JTable table) {
        for (int col = 0; col < table.getColumnCount(); col++) {
            TableColumn column = table.getColumnModel().getColumn(col);
            int maxWidth = 0;

            // Column header width
            // récupère le rendu par défaut des en-têtes de colonne du tableau.
            // Chaque JTable possède un en-tête, affiché en haut du tableau et contient les
            // noms des colonnes.
            TableCellRenderer headerRenderer = table.getTableHeader().getDefaultRenderer();

            // le rendu par défaut des en-têtes de colonne pour créer un composant Swing qui
            // représente l'en-tête de la colonne spécifiée par le paramètre col.
            Component headerComp = headerRenderer.getTableCellRendererComponent(table, column.getHeaderValue(), false,
                    false, 0, col);

            // compare la largeur maximale actuelle avec la largeur du composant Swing
            // garde la plus grande des deux.
            maxWidth = Math.max(maxWidth, headerComp.getPreferredSize().width);

            // Column content width
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer cellRenderer = table.getCellRenderer(row, col);
                Component comp = table.prepareRenderer(cellRenderer, row, col);
                maxWidth = Math.max(maxWidth, comp.getPreferredSize().width);
            }

            // Définir la largeur préférée de la colonne avec un peu de marge
            column.setPreferredWidth(maxWidth + 10);
        }
    }
}
