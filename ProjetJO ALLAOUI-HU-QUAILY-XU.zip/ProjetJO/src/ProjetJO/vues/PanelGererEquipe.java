/**
 * @author HU Shuya
 */

package ProjetJO.vues;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelGererEquipe extends JPanel {

    // -----------------------------
    // Attributs
    // -----------------------------
    // champs de texte: ce que vous entrez
    private JTextField num;
    private JTextField nom;
    private JTextField nbmembres;
    private JTextField description;
    private JTextField creationDate;
    private JTextField pays;

    // label: ce que vous voyez
    private JLabel numLabel;
    private JLabel nameLabel;
    private JLabel nbmembresLabel;
    private JLabel descriptionLabel;
    private JLabel creationDateLabel;
    private JLabel countryLabel;
    // bouton: ce que vous cliquez
    private JButton addButton;
    private JButton deleteButton;

    // --------------------------------------------
    // Constructeur
    // --------------------------------------------
    public PanelGererEquipe() {

        // --------------------------------------------
        // Initialiser les composants
        // --------------------------------------------
        numLabel = new JLabel("Num de l'équipe:");
        num = new JTextField(50);

        nameLabel = new JLabel("Nom de l'équipe:");
        nom = new JTextField(50);

        nbmembresLabel = new JLabel("Nombre de membres:");
        nbmembres = new JTextField(50);

        descriptionLabel = new JLabel("Description de l'équipe:");
        description = new JTextField(500);

        creationDateLabel = new JLabel("Date de création (dd/MM/yyyy):");
        creationDate = new JTextField(10);

        countryLabel = new JLabel("Pays de l'équipe:");
        pays = new JTextField(50);

        addButton = new JButton("Ajouter équipe");
        deleteButton = new JButton("Supprimer équipe");

        nom.setHorizontalAlignment(JLabel.CENTER);

        // --------------------------------
        // Panneau pour l'ajout
        // --------------------------------
        // setLayout(new GridLayout(5, 5));
        add(numLabel);
        add(num);
        add(nameLabel);
        add(nom);
        add(nbmembresLabel);
        add(nbmembres);
        add(descriptionLabel);
        add(description);
        add(creationDateLabel);
        add(creationDate);
        add(countryLabel);
        add(pays);
        add(addButton);
        add(deleteButton);

        addButton.setBackground(new Color(230, 200, 100));
        deleteButton.setBackground(new Color(230, 200, 100));

        // --------------------------------------------
        // Configurer la mise en page
        // --------------------------------------------
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // border interieur
        gbc.fill = GridBagConstraints.HORIZONTAL; // remplir horizontalement
        gbc.anchor = GridBagConstraints.CENTER; // centré

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.1;
        add(numLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(num, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.1;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(nom, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.1;
        add(nbmembresLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(nbmembres, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.1;
        add(descriptionLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(description, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.1;
        add(creationDateLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(creationDate, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0.1;
        add(countryLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(pays, gbc);

        // --------------------------------------------
        // Créer un panneau pour les boutons
        // --------------------------------------------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.setBackground(new Color(255, 255, 204));

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2; // pour que le bouton couvre deux colonnes
        add(buttonPanel, gbc);

        // fond couleur
        setBackground(new Color(255, 255, 204));

        // border entre composant et bordure
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        /// Préparer la gestion des clics sur les boutons
        addButton.setActionCommand("Ajouter équipe");
        deleteButton.setActionCommand("Supprimer équipe");

        // ---------------------------
        // Test boutons dans la vue
        // ---------------------------
        /*
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Epreuve est bien ajouter!");
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Epreuve est bien supprimer!");
            }
        });
*/
    }

    // --------------------------------------------
/*
    public static void main(String[] args) {
        // Creer une fenetre
        JFrame fenetre = new JFrame("Test de ma classe PanelSaisieBouton");
        fenetre.setSize(500, 400);
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        PanelGererEquipe p = new PanelGererEquipe();
        // Ajouter mon instance dans un des conteneurs de la fen?tre
        fenetre.add(p);

        // Afficher la fenetre
        fenetre.setVisible(true);

    }*/

    // -----------------------------
    // Accesseurs
    // -----------------------------
    public String getNum() {
        return num.getText();
    }

    public String getNom() {
        return nom.getText();
    }

    public String getNbMembres() {
        return nbmembres.getText();
    }

    public String getDescription() {
        return description.getText();
    }

    public String getCreationDate() {
        return creationDate.getText();
    }

    public String getPays() {
        return pays.getText();
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

}
