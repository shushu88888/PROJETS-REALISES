/**
 * @author HU Shuya
 */

package ProjetJO.vues;

import javax.swing.*;
import java.awt.*;

public class FenetreGererEpreuve {

    public static void main(String[] args) {
        
        // Créer une fenêtre
        JFrame frame = new JFrame("Gérer les épreuves");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        // Créer un panneau principal avec BorderLayout
        JPanel panelGlobal = new JPanel(new BorderLayout());

        
        // Créer un panneau pour le titre
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("Gérer les épreuves");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabel.setForeground(new Color(230, 230, 210)); // couleur du titre
        titlePanel.add(titleLabel);
        

        // Créer une instance de PanelGererEpreuve
        PanelGererEpreuve panel = new PanelGererEpreuve();

        
        // Ajouter les panneaux au panneau principal
        panelGlobal.add(titlePanel, BorderLayout.NORTH);
        panelGlobal.add(panel, BorderLayout.CENTER);

        
        // Ajouter le panneau principal à la fenêtre
        frame.add(panelGlobal);

        
        // Afficher la fenêtre
        frame.setVisible(true);
    }

}