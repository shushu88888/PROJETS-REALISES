/**
 * @author HU Shuya
 */


package ProjetJO.vues;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;


import ProjetJO.modele.*;




public class FenetreAfficherPla {

    public static void main(String[] args) {

        Planning planning = null;  //déclare vairable planning de type Planning, initialise à null
        
        try { //bloc d'essai
            
            planning = AppliMain.creerPlanning(); 
            //appelle méthode creeerPlanning de la classe AppliMain et affecte le résultat à la variable planning
        } catch (Exception e) {
            //si exception
            
            e.printStackTrace(); //Affiche la trace de l'exception pour aider à identifier la cause de l'erreur.
            
            return; // Si une exception se produit, l'exécution de la méthode principale est interrompue prématurément.
        }

        
        // Créer une fenêtre
        JFrame frame = new JFrame("Le planning des épreuves à venir");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        
        // Créer un panneau principal avec BorderLayout
        JPanel panelGlobal = new JPanel(new BorderLayout());

        
        // Créer un panneau pour le titre
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("Le planning des épreuves à venir");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabel.setForeground(new Color(230, 230, 210));
        titlePanel.add(titleLabel);

        
        // Créer une instance de PanelAfficherPla
        PanelAfficherPla panel = new PanelAfficherPla(planning);
        panel.setBackground(new Color(220, 200, 150));

        
        // Ajouter les panneaux au panneau principal
        panelGlobal.add(titlePanel, BorderLayout.NORTH);
        panelGlobal.add(panel, BorderLayout.CENTER);

        
        // Ajouter le panneau principal à la fenêtre
        frame.add(panelGlobal);

        
        // Afficher la fenêtre
        frame.setVisible(true);
    }
}
