/**
 * @author HU Shuya
 */

package ProjetJO.vues;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelGererEpreuve extends JPanel {
    // --------------------------------------------
    // Attributs
    // --------------------------------------------
    // champs de texte: ce que vous entrez
    private JTextField numEpreuve;
    private JTextField nomEpreuve;
    private JTextField dateDebut;
    private JTextField dateFin;
    private JTextField lieu;
    // label: ce que vous voyez
    private JLabel numLabel;
    private JLabel nomEpreuveLabel;
    private JLabel dateDebutLabel;
    private JLabel dateFinLabel;
    private JLabel lieuLabel;
    // boutons: ce que vous cliquez
    private JButton ajouterButton;
    private JButton supprimerButton;

    // --------------------------------------------
    // Constructeur
    // --------------------------------------------
    public PanelGererEpreuve() {

        // --------------------------------------------
        // Initialiser les composants
        // --------------------------------------------
        numLabel = new JLabel("Num épreuve:");
        numEpreuve = new JTextField(20);
        nomEpreuveLabel = new JLabel("Nom de l'épreuve:");
        nomEpreuve = new JTextField(20);
        dateDebutLabel = new JLabel("Date de début (dd/MM/yyyy):");
        dateDebut = new JTextField(20);
        dateFinLabel = new JLabel("Date de fin (dd/MM/yyyy):");
        dateFin = new JTextField(20);
        lieuLabel = new JLabel("Lieu de l'épreuve:");
        lieu = new JTextField(20);
        ajouterButton = new JButton("Ajouter épreuve");
        supprimerButton = new JButton("Supprimer épreuve");

        // Définir la couleur de fond des boutons
        ajouterButton.setBackground(new Color(230, 200, 100));
        supprimerButton.setBackground(new Color(230, 200, 100));

        // --------------------------------------------
        // Configurer la mise en page
        // --------------------------------------------
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // marge intérieure
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.1;
        add(numLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        add(numEpreuve, gbc);

        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.1;
        add(nomEpreuveLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // pour remplir l'espace horizontal
        add(nomEpreuve, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.1;
        gbc.weightx = 0; // réinitialiser le poids
        add(dateDebutLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // pour remplir l'espace horizontal
        add(dateDebut, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.1;
        gbc.weightx = 0; // réinitialiser le poids
        add(dateFinLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // pour remplir l'espace horizontal
        add(dateFin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.1;
        gbc.weightx = 0; // réinitialiser le poids
        add(lieuLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0; // pour remplir l'espace horizontal
        add(lieu, gbc);

        // --------------------------------------------
        // Créer un panneau pour les boutons
        // --------------------------------------------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(ajouterButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.setBackground(new Color(255, 255, 204));

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2; // pour que le bouton couvre deux colonnes
        add(buttonPanel, gbc);

        // Définir la couleur de fond en jaune clair
        setBackground(new Color(255, 255, 204));

        // Ajouter de la marge entre les composants et les bords de la fenêtre (plus
        // grande marge à gauche et à droite)
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));



        /// Préparer la gestion des clics sur les boutons
        ajouterButton.setActionCommand("Ajouter épreuve");
        supprimerButton.setActionCommand("Supprimer épreuve");


        //---------------------------
        //Test boutons dans la vue
        //---------------------------
/*
        ajouterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //quand on clic sur le bouton ajouter affichage:
                JOptionPane.showMessageDialog(null, "Epreuve est bien ajouter!");
            }
        });
    
        supprimerButton.addActionListener(new ActionListener() {
            //quand on clic sur le bouton supprimer affichage:
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Epreuve est bien supprimer!");
            }
        });
        
*/
    }

    // --------------------------------------------
    // Accesseurs
    // --------------------------------------------
    public String getNumEpreuve() {
        return numEpreuve.getText();
    }

    public String getNomEpreuve() {
        return nomEpreuve.getText();
    }

    public String getDateDebut() {
        return dateDebut.getText();
    }

    public String getDateFin() {
        return dateFin.getText();
    }

    public String getLieu() {
        return lieu.getText();
    }

    public JButton getAjouterButton() {
        return ajouterButton;
    }

    public JButton getSupprimerButton() {
        return supprimerButton;
    }
}
