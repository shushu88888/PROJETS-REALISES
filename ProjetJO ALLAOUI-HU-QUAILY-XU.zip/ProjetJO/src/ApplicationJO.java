/**
 * @author Haiyue Xu
 */
import ProjetJO.modele.*;
import ProjetJO.vues.*;
import ProjetJO.controleur.*;

import java.awt.*;
import javax.swing.*;

public class ApplicationJO {

    public static void main(String[] args) {
        // Initialisation du modèle, des vues et des contrôleurs
        Enregistrement modele = new Enregistrement();
        
        // Épreuves
        PanelGererEpreuve vueEpreuve = new PanelGererEpreuve();
        ControleurManagementEpreuve controleurEpreuve = new ControleurManagementEpreuve(modele, vueEpreuve);
        
        // Équipes
        PanelGererEquipe vueEquipe = new PanelGererEquipe();
        ControleurManagementEquipe controleurEquipe = new ControleurManagementEquipe(modele, vueEquipe);
        
        // Sessions
        PanelGererSessions vueSession = new PanelGererSessions();
        ControleurManagementSession controleurSession = new ControleurManagementSession(modele, vueSession);
        
        // Création et configuration de la fenêtre pour la gestion des sessions
        JFrame frameSession = new JFrame("Gestion des sessions des Jeux Olympiques");
        frameSession.setSize(800, 600);
        frameSession.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panelGlobalSession = new JPanel(new BorderLayout());
        JPanel titlePanelSession = new JPanel();
        titlePanelSession.setBackground(Color.WHITE);
        JLabel titleLabelSession = new JLabel("Gérer les sessions");
        titleLabelSession.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabelSession.setForeground(new Color(50, 50, 50)); // Couleur du texte du titre
        titlePanelSession.add(titleLabelSession);
        panelGlobalSession.add(titlePanelSession, BorderLayout.NORTH);
        panelGlobalSession.add(vueSession, BorderLayout.CENTER);
        frameSession.add(panelGlobalSession);
        frameSession.setVisible(true);
        
        // Ajouter les écouteurs d'action aux boutons de la vue des sessions
        vueSession.getAddButton().addActionListener(controleurSession);
        vueSession.getDeleteButton().addActionListener(controleurSession);
        
        // Création et configuration de la fenêtre pour la gestion des épreuves
        JFrame frameEpreuve = new JFrame("Gérer les épreuves");
        frameEpreuve.setSize(500, 400);
        frameEpreuve.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panelGlobalEpreuve = new JPanel(new BorderLayout());
        JPanel titlePanelEpreuve = new JPanel();
        titlePanelEpreuve.setBackground(Color.WHITE);
        JLabel titleLabelEpreuve = new JLabel("Gérer les épreuves");
        titleLabelEpreuve.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabelEpreuve.setForeground(new Color(50, 50, 50)); // Couleur du texte du titre
        titlePanelEpreuve.add(titleLabelEpreuve);
        panelGlobalEpreuve.add(titlePanelEpreuve, BorderLayout.NORTH);
        panelGlobalEpreuve.add(vueEpreuve, BorderLayout.CENTER);
        frameEpreuve.add(panelGlobalEpreuve);
        frameEpreuve.setVisible(true);
        
        // Ajouter les écouteurs d'action aux boutons de la vue des épreuves
        vueEpreuve.getAjouterButton().addActionListener(controleurEpreuve);
        vueEpreuve.getSupprimerButton().addActionListener(controleurEpreuve);
        
        // Création et configuration de la fenêtre pour la gestion des équipes
        JFrame frameEquipe = new JFrame("Gestion des équipes");
        frameEquipe.setSize(500, 400);
        frameEquipe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panelGlobalEquipe = new JPanel(new BorderLayout());
        JPanel titlePanelEquipe = new JPanel();
        titlePanelEquipe.setBackground(Color.WHITE);
        JLabel titleLabelEquipe = new JLabel("Gérer les équipes");
        titleLabelEquipe.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabelEquipe.setForeground(new Color(50, 50, 50)); // Couleur du texte du titre
        titlePanelEquipe.add(titleLabelEquipe);
        panelGlobalEquipe.add(titlePanelEquipe, BorderLayout.NORTH);
        panelGlobalEquipe.add(vueEquipe, BorderLayout.CENTER);
        frameEquipe.add(panelGlobalEquipe);
        frameEquipe.setVisible(true);
        
        // Ajouter les écouteurs d'action aux boutons de la vue des équipes
        vueEquipe.getAddButton().addActionListener(controleurEquipe);
        vueEquipe.getDeleteButton().addActionListener(controleurEquipe);
        
        // Initialisation du planning
        Planning planning = null;  
        
        try { 
            planning = AppliMain.creerPlanning(); 
            
        } catch (Exception e) {
            
            e.printStackTrace(); 
            return; 
        }

        // Créer une fenêtre pour afficher le planning des épreuves
        JFrame framePlanning = new JFrame("Le planning des épreuves à venir");
        framePlanning.setSize(800, 600);
        framePlanning.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JPanel panelGlobalPlanning = new JPanel(new BorderLayout());

        // Créer un panneau pour le titre
        JPanel titlePanelPlanning = new JPanel();
        titlePanelPlanning.setBackground(Color.WHITE);
        JLabel titleLabelPlanning = new JLabel("Le planning des épreuves à venir");
        titleLabelPlanning.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabelPlanning.setForeground(new Color(50, 50, 50));
        titlePanelPlanning.add(titleLabelPlanning);

        // Créer une instance de PanelAfficherPla
        PanelAfficherPla panelPlanning = new PanelAfficherPla(planning);
        panelPlanning.setBackground(new Color(220, 200, 150));

        // Ajouter les panneaux au panneau principal
        panelGlobalPlanning.add(titlePanelPlanning, BorderLayout.NORTH);
        panelGlobalPlanning.add(panelPlanning, BorderLayout.CENTER);

        // Ajouter le panneau principal à la fenêtre
        framePlanning.add(panelGlobalPlanning);

        // Afficher la fenêtre
        framePlanning.setVisible(true);
    }
}
